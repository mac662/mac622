<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>GOFTech Solutions</title>

    <!--
    - favicon
  -->
    <link rel="shortcut icon" href="{{ asset('assets/images/logo-removebg-preview.png') }}" type="image/svg+xml">

    <!--
    - custom css link
  -->
    <link rel="stylesheet" href="{{ asset('/assets/css/style.css') }}">
    <!--
    - google font link
  -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Cuprum:wght@500;600;700&family=Poppins:wght@400;500;600&display=swap"
        rel="stylesheet">

    <!--
    - preload images
  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preload" as="image" href="./assets/images/hero-banner.png">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>

</head>

<body>

    <!--
    - #HEADER
  -->

    <header class="header" data-header>
        <div class="container">

            <div class="neon-link ">
                <!-- <h1>My Changing Neon Heading</h1> -->
                <img src="assets/images/logo-removebg-preview.png" alt=""
                    style="height: 50px; object-fit: cover;">
                <a href="#" class="logo">GOFTech</a>
            </div>

            <nav class="navbar" data-navbar>

                <div class="wrapper">
                    <div class="neon-link">
                        <a href="#" class="logo">GOFTech</a>
                    </div>

                    <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
                        <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
                    </button>
                </div>

                <ul class="navbar-list">

                    <li>
                        <a href="#home" class="navbar-link" data-nav-link>Home</a>
                    </li>

                    <li>
                        <a href="#about" class="navbar-link" data-nav-link>About</a>
                    </li>

                    <li>
                        <a href="#services" class="navbar-link" data-nav-link>Services</a>
                    </li>

                    <li>
                        <a href="#features" class="navbar-link" data-nav-link>Why US?</a>
                    </li>

                    <li>
                        <a href="#faq" class="navbar-link" data-nav-link>FAQ</a>
                    </li>

                    {{-- <li>
                        <a href="#contact-us" class="navbar-link" data-nav-link>Contact Us</a>
                    </li> --}}

                </ul>

            </nav>

            <button class="nav-open-btn" aria-label="open menu" data-nav-toggler>
                <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
            </button>

            <a href="https://wa.link/sueqop" class="btn-outline"><i class="fa-brands fa-whatsapp fa-beat fa-xl"
                    style="color: #3b3d3e; padding-right:6px"></i>Lets talk</a>

            <div class="overlay" data-nav-toggler data-overlay></div>

        </div>
    </header>


    <main>
        <article>

            <!--
        - #HERO
      -->

            <section class="section hero" id="home" aria-label="hero">
                <div class="container">

                    <div class="hero-content">

                        <p class="hero-subtitle has-before">Welcome to GOFTECHSOLUTIONS FAMILY</p>

                        <h1 class="h1 hero-title">Seamless Solutions, Infinite Possibilities</h1>

                        <p class="hero-text">
                            We are a trailblazing tech company driven by innovation and dedicated to empowering
                            businesses and
                            individuals to thrive in the digital age. Our mission is to transform ideas into reality,
                            providing
                            cutting-edge tech solutions that simplify processes, optimize efficiency, and propel
                            success.
                        </p>

                        <!-- <div class="btn-group">
              <a href="#" class="btn btn-primary">Discover More</a>

              <button class="flex-btn">
                <div class="btn-icon">
                  <ion-icon name="play" aria-hidden="true"></ion-icon>
                </div>

                <span class="span">How it works</span>
              </button>
            </div> -->

                    </div>

                    <figure class="hero-banner has-before img-holder" style="--width: 650; --height: 650;">
                        <img src="./assets/images/logo.jpeg" width="650" height="650" alt="hero banner"
                            class="img-cover">
                    </figure>

                </div>
            </section>





            <!--
        - #ABOUT
      -->

            <section class="section about" id="about" aria-label="about">
                <div class="container">

                    <figure class="about-banner">
                        <img src="./assets/images/about-banner.png" width="802" height="654" loading="lazy"
                            alt="about banner" class="w-100">
                    </figure>

                    <div class="about-content">

                        <h2 class="h2-sm section-title">We create some things, Design for your success future.</h2>

                        <p class="section-text">
                            GOFTECHSOLUTIONS is the brainchild of four visionary friends, united by a shared passion for
                            technology
                            and innovation. Originating as the "Gang of FOUR," their journey began with a common goal -
                            to
                            revolutionize the tech industry and empower businesses and individuals with cutting-edge
                            solutions.
                            We are more than just a tech company; we are your growth partners. Join us on this exciting
                            journey as we
                            harness the latest technologies, implement industry best practices, and turn your visions
                            into reality.
                            Let's embrace the future together with GOFTECHSOLUTIONS.
                        </p>

                        <!-- <ul class="about-list">

              <li class="has-before">
                Price of additional materials or parts (if needed)
              </li>

              <li class="has-before">
                Transportation cost for carrying new materials/parts
              </li>

              <li class="has-before">
                You will get 100% money back offer.
              </li>

            </ul> -->

                        <div class="btn-group">
                            <!-- <a href="#" class="btn btn-primary">Know More</a> -->

                            <button class="flex-btn">
                                <div class="btn-icon">
                                    <ion-icon name="medal-outline" aria-hidden="true"></ion-icon>
                                </div>

                                <span class="span">1+ Years Experience</span>
                            </button>
                        </div>

                    </div>

                </div>
            </section>





            <!--
        - #SERVICE
      -->

            <section class="section service" id="services" aria-label="service">
                <div class="container">

                    <p class="section-subtitle text-center">-What We Offer-</p>

                    <h2 class="h2 section-title text-center">Our Services</h2>

                    <p class="section-text text-center">
                        From web and app development to SEO and social media marketing, our comprehensive services
                        empower
                        businesses
                        to thrive in the digital landscape.
                    </p>

                    <ul class="grid-list">

                        <li>
                            <div class="service-card has-after">

                                <figure class="card-icon">
                                    <img src="./assets/images/search.png" width="140" height="140"
                                        loading="lazy" alt="UI/UX Creative Design" class="img">
                                </figure>

                                <div class="card-content">

                                    <h3 class="h3 card-title">Search</h3>
                                    <p class="card-text">
                                    <ul class="custom-list">
                                        <li>Search Engine Optimization (SEO)</li>
                                        <li>Search Engine Marketing (SEM)</li>
                                        <li>Local SEO</li>
                                        <li>E-Commerce SEO</li>
                                        <li>Video SEO</li>
                                    </ul>
                                    </p>

                                    <!-- <a href="#" class="btn-link">
                    <span class="span">Read More</span>

                    <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
                  </a> -->

                                </div>

                            </div>
                        </li>
                        <li>
                            <div class="service-card has-after">

                                <figure class="card-icon">
                                    <img src="./assets/images/social.png" width="140" height="140"
                                        loading="lazy" alt="UI/UX Creative Design" class="img">
                                </figure>

                                <div class="card-content">

                                    <h3 class="h3 card-title">Social</h3>

                                    <p class="card-text">
                                    <ul class="custom-list">
                                        <li>Social Media Marketing</li>
                                        <li>Paid Social Media</li>
                                        <li>Influencer Marketing</li>
                                        <li>Community Management</li>
                                    </ul>
                                    </p>

                                    <!-- <a href="#" class="btn-link">
                    <span class="span">Read More</span>

                    <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
                  </a> -->

                                </div>

                            </div>
                        </li>
                        <li>
                            <div class="service-card has-after">

                                <figure class="card-icon">
                                    <img src="./assets/images/analytics.png" width="140" height="140"
                                        loading="lazy" alt="UI/UX Creative Design" class="img">
                                </figure>

                                <div class="card-content">

                                    <h3 class="h3 card-title">Analytics & Strategy</h3>

                                    <p class="card-text">
                                    <ul class="custom-list">
                                        <li>Marketing Strategy</li>
                                        <li>Marketing Advice</li>
                                        <li>Web Analytics</li>
                                    </ul>

                                    </p>

                                    <!-- <a href="#" class="btn-link">
                    <span class="span">Read More</span>

                    <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
                  </a> -->

                                </div>

                            </div>
                        </li>
                        <li>
                            <div class="service-card has-after">

                                <figure class="card-icon">
                                    <img src="./assets/images/website.png" width="140" height="140"
                                        loading="lazy" alt="UI/UX Creative Design" class="img">
                                </figure>

                                <div class="card-content">

                                    <h3 class="h3 card-title">Websites</h3>

                                    <p class="card-text">
                                    <ul class="custom-list">
                                        <li>Website Development</li>
                                        <li>Website Maintenance</li>
                                        <li>Website Customization</li>
                                    </ul>
                                    </p>

                                    <!-- <a href="#" class="btn-link">
                    <span class="span">Read More</span>

                    <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
                  </a> -->

                                </div>

                            </div>
                        </li>

                        <li>
                            <div class="service-card has-after">

                                <figure class="card-icon">
                                    <img src="./assets/images/website.png" width="140" height="140"
                                        loading="lazy" alt="App Development" class="img">
                                </figure>

                                <div class="card-content">

                                    <h3 class="h3 card-title">Website Platforms</h3>

                                    <p class="card-text">
                                    <ul class="custom-list">
                                        <li>WordPress</li>
                                        <li>Shopify</li>
                                        <li>Wix</li>
                                        <li>Webflow</li>
                                        <li>Custom Websites</li>
                                    </ul>

                                    </p>

                                    <!-- <a href="#" class="btn-link">
                    <span class="span">Read More</span>

                    <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
                  </a> -->

                                </div>

                            </div>
                        </li>

                        <li>
                            <div class="service-card has-after">

                                <figure class="card-icon">
                                    <img src="./assets/images/cyber.png" width="140" height="140"
                                        loading="lazy" alt="Graphic Design" class="img">
                                </figure>

                                <div class="card-content">

                                    <h3 class="h3 card-title">Support & Cybersecurity</h3>

                                    <p class="card-text">
                                    <ul class="custom-list">
                                        <li>Support & IT</li>
                                        <li>DevOps & Cloud</li>
                                        <li>Cybersecurity</li>
                                        <li>Development for Streamers</li>
                                        <li>Convert Files</li>
                                    </ul>
                                    </p>

                                    <!-- <a href="#" class="btn-link">
                    <span class="span">Read More</span>

                    <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
                  </a> -->

                                </div>

                            </div>
                        </li>

                        <li>
                            <div class="service-card has-after">

                                <figure class="card-icon">
                                    <img src="./assets/images/app.png" width="140" height="140" loading="lazy"
                                        alt="Professional Content Writer" class="img">
                                </figure>

                                <div class="card-content">

                                    <h3 class="h3 card-title">Application Development</h3>

                                    <p class="card-text">
                                    <ul class="custom-list">
                                        <li>Software Development</li>
                                        <li>Mobile App Development</li>
                                        <li>Web Applications</li>
                                        <li>Desktop Applications</li>
                                        <li>Game Development</li>
                                        <li>AI Development</li>
                                        <li>Chatbot Development</li>
                                    </ul>

                                    </p>

                                    <!-- <a href="#" class="btn-link">
                    <span class="span">Read More</span>

                    <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
                  </a> -->

                                </div>

                            </div>
                        </li>
                        <li>
                            <div class="service-card has-after">

                                <figure class="card-icon">
                                    <img src="./assets/images/methods.png" width="140" height="140"
                                        loading="lazy" alt="UI/UX Creative Design" class="img">
                                </figure>

                                <div class="card-content">

                                    <h3 class="h3 card-title">Methods & Techniques</h3>

                                    <p class="card-text">
                                    <ul class="custom-list">
                                        <li>Video Marketing</li>
                                        <li>E-Commerce Marketing</li>
                                        <li>Email Marketing</li>
                                        <li>Guest Posting</li>
                                        <li>Affiliate Marketing</li>
                                        <li>Display Advertising</li>
                                        <li>Public Relations</li>
                                        <li>Text Message Marketing</li>
                                    </ul>
                                    </p>

                                    <!-- <a href="#" class="btn-link">
                    <span class="span">Read More</span>

                    <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
                  </a> -->

                                </div>

                            </div>
                        </li>
                    </ul>

                    <!-- <a href="#" class="btn btn-primary">Get Started</a> -->

                </div>
            </section>





            <!--
        - #FEATURES
      -->

            <section class="section features" id="features" aria-label="features">
                <div class="container">

                    <p class="section-subtitle text-center">-Why Choose Us-</p>

                    <h2 class="h2 section-title text-center">Reasons to Choose Us</h2>

                    <p class="section-text text-center">
                        Our passionate team of tech enthusiasts brings diverse skills to the table, ensuring you receive
                        top-notch
                        service and support.
                    </p>

                    <ul class="grid-list">

                        <li>
                            <div class="features-card">

                                <data class="card-number" value="01">01</data>

                                <h3 class="h3 card-title">Collaborative Partnership</h3>

                                <p class="card-text">
                                    Together, we achieve lasting success.
                                </p>

                            </div>
                        </li>

                        <li>
                            <div class="features-card">

                                <data class="card-number" value="02">02</data>

                                <h3 class="h3 card-title">Customer-Centric Approach</h3>

                                <p class="card-text">
                                    Your goals are our primary focus.
                                </p>

                            </div>
                        </li>

                        <li>
                            <div class="features-card">

                                <data class="card-number" value="03">03</data>

                                <h3 class="h3 card-title">Full Spectrum of Tech Services</h3>

                                <p class="card-text">
                                    One-stop-shop for all your tech needs.
                                </p>

                            </div>
                        </li>


                        <li>
                            <div class="features-card">

                                <data class="card-number" value="04">04</data>

                                <h3 class="h3 card-title">Innovative Solutions, Proven Results</h3>

                                <p class="card-text">
                                    Tailored tech solutions with a track record of success.
                                </p>

                            </div>
                        </li>


                        <li>
                            <div class="features-card">

                                <data class="card-number" value="05">05</data>

                                <h3 class="h3 card-title">Forward-Thinking and Future-Ready</h3>

                                <p class="card-text">
                                    Embracing emerging technologies for long-term relevance.
                                </p>

                            </div>
                        </li>

                        <li>
                            <div class="features-card">

                                <data class="card-number" value="06">06</data>

                                <h3 class="h3 card-title">The Power of Four: Gang of FOUR's Expertise</h3>

                                <p class="card-text">
                                    Diverse skills from a passionate team of tech enthusiasts.
                                </p>

                            </div>
                        </li>
                    </ul>

                </div>
            </section>





            <!--
        - #FAQ
      -->

            <section id="faq" class="section faq" aria-label="frequently asked questions">
                <div class="container">

                    <div class="title-wrapper">
                        <h2 class="h2 section-title">Discover Frequently Asked Questions?</h2>

                        <!-- <a href="#" class="btn btn-primary">Work Together</a> -->
                    </div>

                    <ul class="grid-list">

                        <li>
                            <div class="faq-card">

                                <button class="card-action" data-accordion-action>
                                    <h3 class="h3 card-title">
                                        01. What industries do you serve?
                                    </h3>

                                    <div class="action-icon">
                                        <ion-icon name="add-outline" aria-hidden="true" class="open"></ion-icon>
                                        <ion-icon name="remove-outline" aria-hidden="true" class="close"></ion-icon>
                                    </div>
                                </button>

                                <div class="card-content">
                                    <p>
                                        We cater to a wide range of industries, including e-commerce, healthcare,
                                        finance, education,
                                        entertainment, and more. Our versatile expertise allows us to tailor solutions
                                        for businesses across
                                        diverse sectors.
                                    </p>
                                </div>

                            </div>
                        </li>

                        <li>
                            <div class="faq-card">

                                <button class="card-action" data-accordion-action>
                                    <h3 class="h3 card-title">
                                        02. How do you ensure the security of our data and systems?
                                    </h3>

                                    <div class="action-icon">
                                        <ion-icon name="add-outline" aria-hidden="true" class="open"></ion-icon>
                                        <ion-icon name="remove-outline" aria-hidden="true" class="close"></ion-icon>
                                    </div>
                                </button>

                                <div class="card-content">
                                    <p>
                                        At GOFTECHSOLUTIONS, we prioritize cybersecurity. We employ robust encryption,
                                        multi-layered
                                        authentication, and regular security audits to safeguard your data and systems
                                        from potential
                                        threats, ensuring maximum protection.
                                    </p>
                                </div>

                            </div>
                        </li>

                        <li>
                            <div class="faq-card">

                                <button class="card-action" data-accordion-action>
                                    <h3 class="h3 card-title">
                                        03. Can you handle both small-scale startups and large enterprises?
                                    </h3>

                                    <div class="action-icon">
                                        <ion-icon name="add-outline" aria-hidden="true" class="open"></ion-icon>
                                        <ion-icon name="remove-outline" aria-hidden="true" class="close"></ion-icon>
                                    </div>
                                </button>

                                <div class="card-content">
                                    <p>
                                        Absolutely! Our services are designed to cater to businesses of all sizes.
                                        Whether you are a budding
                                        startup or an established enterprise, we have the expertise and scalability to
                                        address your specific
                                        needs and help you achieve your goals.
                                    </p>
                                </div>

                            </div>
                        </li>

                        <li>
                            <div class="faq-card">

                                <button class="card-action" data-accordion-action>
                                    <h3 class="h3 card-title">
                                        04. What sets you apart from other tech companies?
                                    </h3>

                                    <div class="action-icon">
                                        <ion-icon name="add-outline" aria-hidden="true" class="open"></ion-icon>
                                        <ion-icon name="remove-outline" aria-hidden="true" class="close"></ion-icon>
                                    </div>
                                </button>

                                <div class="card-content">
                                    <p>
                                        What makes us unique is our holistic approach and the synergy of our diverse
                                        team. The fusion of
                                        development, marketing, design, and cybersecurity expertise ensures
                                        comprehensive solutions,
                                        empowering your business to thrive in the ever-evolving tech landscape.
                                    </p>
                                </div>

                            </div>
                        </li>

                        <li>
                            <div class="faq-card">

                                <button class="card-action" data-accordion-action>
                                    <h3 class="h3 card-title">
                                        05. How do you stay updated with the latest technological advancements?
                                    </h3>

                                    <div class="action-icon">
                                        <ion-icon name="add-outline" aria-hidden="true" class="open"></ion-icon>
                                        <ion-icon name="remove-outline" aria-hidden="true" class="close"></ion-icon>
                                    </div>
                                </button>

                                <div class="card-content">
                                    <p>
                                        Continuous learning and staying at the forefront of technology are part of our
                                        DNA. Our team
                                        regularly attends industry conferences, undergoes training, and actively engages
                                        in research to keep
                                        up with emerging trends and cutting-edge innovations, delivering future-ready
                                        solutions to our
                                        clients.
                                    </p>
                                </div>

                            </div>
                        </li>

                    </ul>

                </div>
            </section>

        </article>
    </main>


    <!--
    - #FOOTER
  -->

    <footer class="footer">

        <div class="footer-top section">
            <div class="container">

                <div class="footer-brand">

                    <a href="#" class="logo">GOFTECHSOLUTIONS</a>

                    <p class="footer-text">
                        Your Tech Journey, Elevated: Partner with us for Cutting-Edge Excellence.
                    </p>

                    {{-- <form action="" class="newsletter-form">
                        <input type="email" name="email_address" placeholder="Enter your email" required
                            class="email-field">

                        <button type="submit" class="form-btn">
                            <ion-icon name="paper-plane" aria-hidden="true"></ion-icon>
                        </button>
                    </form> --}}

                </div>

                <ul class="footer-list">

                    <li>
                        <p class="footer-list-title">Our Services</p>
                    </li>

                    <li>
                        <a href="#services" class="footer-link">Social</a>
                    </li>

                    <li>
                        <a href="#services" class="footer-link">Method & Techniques</a>
                    </li>

                    <li>
                        <a href="#services" class="footer-link">Analytics & Strategy</a>
                    </li>

                    <li>
                        <a href="#services" class="footer-link">Websites</a>
                    </li>

                    <li>
                        <a href="#services" class="footer-link">Websites Platform</a>
                    </li>

                    <li>
                        <a href="#services" class="footer-link">App Development</a>
                    </li>

                    <li>
                        <a href="#services" class="footer-link">Support & CyberSecurity</a>
                    </li>

                </ul>

                <ul class="footer-list">

                    <li>
                        <p class="footer-list-title">Company</p>
                    </li>

                    <li>
                        <a href="#about" class="footer-link">About Company</a>
                    </li>

                    <li>
                        <a href="#services" class="footer-link">Our Services</a>
                    </li>

                    <!-- <li>
            <a href="#contact-us" class="footer-link">Contact Us</a>
          </li> -->

                </ul>

                <ul class="footer-list">

                    <li>
                        <p class="footer-list-title">Contact Us</p>
                    </li>

                    <li class="footer-item">
                        <ion-icon name="location" aria-hidden="true"></ion-icon>

                        <address class="contact-link address">
                            I-10 Islamabad
                        </address>
                    </li>

                    <li class="footer-item">
                        <ion-icon name="call" aria-hidden="true"></ion-icon>

                        <a href="tel:+7894631546876" class="contact-link">+92 335 5265622</a>
                    </li>

                    <li class="footer-item">
                        <ion-icon name="mail" aria-hidden="true"></ion-icon>

                        <a href="mailto:info@gottechsolutions.com" class="contact-link">info@gottechsolutions.com</a>
                    </li>

                    <li class="footer-item">
                        <ul class="social-list">

                            <li>
                                <a href="#" class="social-link">
                                    <ion-icon name="logo-facebook"></ion-icon>
                                </a>
                            </li>

                            <li>
                                <a href="#" class="social-link">
                                    <ion-icon name="logo-twitter"></ion-icon>
                                </a>
                            </li>

                            <li>
                                <a href="#" class="social-link">
                                    <ion-icon name="logo-instagram"></ion-icon>
                                </a>
                            </li>

                            <li>
                                <a href="#" class="social-link">
                                    <ion-icon name="logo-pinterest"></ion-icon>
                                </a>
                            </li>

                        </ul>
                    </li>

                </ul>

            </div>
        </div>

        <div class="footer-bottom">
            <div class="container">

                <p class="copyright">
                    &copy; 2023 GOFTechSolutions</a>
                </p>

                <ul class="footer-bottom-list">

                    <li>
                        <a href="#" class="footer-bottom-link">Privacy Policy</a>
                    </li>

                    <li>
                        <a href="#" class="footer-bottom-link">Terms of Use</a>
                    </li>

                </ul>

            </div>
        </div>

    </footer>





    <!--
    - custom js link
  -->
    <script src="./assets/js/script.js"></script>
    <script src="./assets/js/contact-from.js"></script>

    <!--
    - ionicon link
  -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>
